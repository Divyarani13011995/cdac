
class Addition{
	public static void main(String arg[]){
		// comments

		/*
		int number1 = 10;  
		int number2 = 20;
		int add;
		add = number1 + number2;
		System.out.println("Addition of Numbers");
		System.out.println(add);
		*/

		/*
		float number1 = 10.0f;  
		float number2 = 20;
		float add;
		add = number1 + number2;
		System.out.println("Addition of Numbers");
		System.out.println(add);
		*/

		/*if(false){
			System.out.println("in IF block");	
		}
		else{
			System.out.println("in else block");
		}
		
		if(true){
			System.out.println("in IF block");	
		}
		else{
			System.out.println("in else block");
		}*/

		/*
		int a = 10;
		if(a<5 && a>10){
			System.out.println("in IF block");	
		}
		else{
			System.out.println("in else block");
		}
		*/

		int a = 61;
		if(a<50){
			System.out.println("in if block");	
		}
		else if(a>15){
			System.out.println("in else-if block");
		}
		else{
			System.out.println("in else block");
		}

		System.out.println("outside IF-ELSE");
	

	}  // main end

} class end